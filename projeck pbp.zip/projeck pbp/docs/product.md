# Product API Spec

## Create Product API

Endpoint : POST /api/product

Headers : 
- Authorization : token

Request Body :

```json
{
  "brand" : "Samsung",
  "model" : "Galaxy S21",
  "price" : 999.99,
  "color" : "Black",
  "storage" : "256GB"
}
```

Response Body Success:
```json
{
  "data" : {
    "id" : 1,
    "brand" : "Samsung",
    "model" : "Galaxy S21",
    "price" : 999.99,
    "color" : "Black",
    "storage" : "256GB"
  }
}
```

Respon Body Error:
```json
{
  "errors" : "Invalid price format"
}
```

## Update product API
Endpoint : GET /api/product/:id

Headers :

-Authorization : token
Response Body Success :

```json
  {
  "data" : {
    "id" : 1,
    "brand" : "Samsung",
    "model" : "Galaxy S21",
    "price" : 999.99,
    "color" : "Black",
    "storage" : "256GB"
  }
}
```

```json
{
  "errors" : "Product not found"
}
```

## Get product API
Endpoint : GET /api/product/:id

Headers :

Authorization : token
Response Body Success :
```json
 {
  "data" : {
    "id" : 1,
    "brand" : "Samsung",
    "model" : "Galaxy S21",
    "price" : 999.99,
    "color" : "Black",
    "storage" : "256GB"
  }
}
```
 Response Body Error :
```json
{
  "errors" : "Product not found"
}
```
## Serch product API
Endpoint : GET /api/product

Headers :
-Authorization : token

Query params :

brand : Search by brand, using like, optional
model : Search by model using like, optional
color : Search by color using like, optional
storage : Search by storage using like, optional
page : number of page, default 1
size : size per page, default 10

Response Body Success :

```json
{
  "data" : [
    {
      "id" : 1,
      "brand" : "Samsung",
      "model" : "Galaxy S21",
      "price" : 999.99,
      "color" : "Black",
      "storage" : "256GB"
    },
    {
      "id" : 2,
      "brand" : "Samsung",
      "model" : "Galaxy S21 Ultra",
      "price" : 1299.99,
      "color" : "Phantom Black",
      "storage" : "512GB"
    }
  ],
  "paging" : {
    "page" : 1,
    "total_page" : 3,
    "total_item" : 30
  }
}
```

Respon Body Error
```json
{
  "errors" : "No product found"
}
```

## Remove Product API
 Endpoint : DELETE /api/product/:id

Headers :

-Authorization : token
Response Body Success :

```json
{
  "data" : "OK"
}
```

```json
{
  "errors" : "Product not found"
}
```
