// test/user.test.js

const request = require('supertest');
const app = require('../src/main'); // Assuming your Express app is in src/main.js

describe('User endpoints', () => {
  it('should register a new user', async () => {
    const res = await request(app)
      .post('/api/users')
      .send({
        username: 'testuser',
        password: 'password',
        name: 'Test User',
      });
    expect(res.statusCode).toEqual(201);
    expect(res.body).toHaveProperty('username', 'testuser');
    // Add more assertions as needed
  });

  // Add more test cases for other user endpoints
});