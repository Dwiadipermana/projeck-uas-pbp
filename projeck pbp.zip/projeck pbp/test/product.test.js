// test/product.test.js

const request = require('supertest');
const app = require('../src/main'); // Assuming your Express app is in src/main.js

describe('Product endpoints', () => {
  it('should create a new product', async () => {
    const res = await request(app)
      .post('/api/products')
      .send({
        brand: 'Samsung',
        model: 'Galaxy S21',
        price: 999.99,
        color: 'Black',
        storage: '256GB',
      });
    expect(res.statusCode).toEqual(201);
    expect(res.body).toHaveProperty('id');
    expect(res.body).toHaveProperty('brand', 'Samsung');
    // Add more assertions as needed
  });

  // Add more test cases for other product endpoints
});