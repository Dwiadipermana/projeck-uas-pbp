// test/test-util.js

// Utility function to generate a random username
const generateRandomUsername = () => {
    return `user${Math.floor(Math.random() * 100000)}`;
  };
  
  module.exports = {
    generateRandomUsername,
  };