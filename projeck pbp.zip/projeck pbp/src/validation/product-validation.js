// validation/product-validation.js

const { body, validationResult } = require('express-validator');

const createProductValidationRules = () => {
  return [
    body('brand').notEmpty().withMessage('Brand is required'),
    body('model').notEmpty().withMessage('Model is required'),
    body('price').isFloat({ min: 0 }).withMessage('Price must be a positive number'),
    body('color').notEmpty().withMessage('Color is required'),
    body('storage').notEmpty().withMessage('Storage is required'),
  ];
};

const updateProductValidationRules = () => {
  return [
    body('brand').optional().notEmpty().withMessage('Brand is required'),
    body('model').optional().notEmpty().withMessage('Model is required'),
    body('price').optional().isFloat({ min: 0 }).withMessage('Price must be a positive number'),
    body('color').optional().notEmpty().withMessage('Color is required'),
    body('storage').optional().notEmpty().withMessage('Storage is required'),
  ];
};

const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (errors.isEmpty()) {
    return next();
  }
  return res.status(400).json({ errors: errors.array() });
};

module.exports = {
  createProductValidationRules,
  updateProductValidationRules,
  validate,
};