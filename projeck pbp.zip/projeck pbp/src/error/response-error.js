// error/response-error.js

const responseError = (res, statusCode, message) => {
    res.status(statusCode).json({ error: message });
  };
  
  module.exports = responseError;