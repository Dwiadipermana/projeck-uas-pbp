// middleware/auth-middleware.js

const jwt = require('jsonwebtoken');
const User = require('../models/User');
const responseError = require('../error/response-error');

const authMiddleware = async (req, res, next) => {
  const token = req.header('Authorization').replace('Bearer ', '');
  try {
    const decoded = jwt.verify(token, 'secret'); // Ganti 'secret' dengan secret key Anda
    const user = await User.findOne({ username: decoded.username });
    if (!user) {
      throw new Error();
    }
    req.user = user;
    next();
  } catch (error) {
    responseError(res, 401, 'Unauthorized');
  }
};

module.exports = authMiddleware;