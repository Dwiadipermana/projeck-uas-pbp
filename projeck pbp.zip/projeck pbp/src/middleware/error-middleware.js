// middleware/error-middleware.js

const responseError = require('../error/response-error');

const errorMiddleware = (error, req, res, next) => {
  console.error(error);
  responseError(res, 500, 'Internal server error');
};

module.exports = errorMiddleware;