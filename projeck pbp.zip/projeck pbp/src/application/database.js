// application/database.js

const mongoose = require('mongoose');

const connectDB = async () => {
  try {
    await mongoose.connect(`root:@localhost:3306/uas_pbp_dwi_sandy_aria_db`, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log('Connected to database');
  } catch (error) {
    console.error('Error connecting to database:', error);
    process.exit(1); // Exit with failure
  }
};

module.exports = connectDB;