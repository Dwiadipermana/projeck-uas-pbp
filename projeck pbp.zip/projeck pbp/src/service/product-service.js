// services/productService.js

const Product = require('../models/Product');

const createProduct = async (productData) => {
  try {
    const product = new Product(productData);
    await product.save();
    return product;
  } catch (error) {
    throw new Error('Unable to create product');
  }
};

const updateProduct = async (productId, productData) => {
  try {
    const product = await Product.findByIdAndUpdate(productId, productData, { new: true });
    if (!product) {
      throw new Error('Product not found');
    }
    return product;
  } catch (error) {
    throw new Error('Unable to update product');
  }
};

const getProductById = async (productId) => {
  try {
    const product = await Product.findById(productId);
    if (!product) {
      throw new Error('Product not found');
    }
    return product;
  } catch (error) {
    throw new Error('Unable to get product by id');
  }
};

const searchProducts = async (query) => {
  try {
    // Implement search logic here based on query parameters
    const products = await Product.find(query);
    return products;
  } catch (error) {
    throw new Error('Unable to search products');
  }
};

const deleteProduct = async (productId) => {
  try {
    const product = await Product.findByIdAndDelete(productId);
    if (!product) {
      throw new Error('Product not found');
    }
    return 'OK';
  } catch (error) {
    throw new Error('Unable to delete product');
  }
};

module.exports = {
  createProduct,
  updateProduct,
  getProductById,
  searchProducts,
  deleteProduct,
};