// services/userService.js

const User = require('../models/User');

const registerUser = async (userData) => {
  try {
    const user = new User(userData);
    await user.save();
    return user;
  } catch (error) {
    throw new Error('Unable to register user');
  }
};

const loginUser = async (username, password) => {
  try {
    const user = await User.findOne({ username, password });
    if (!user) {
      throw new Error('Username or password wrong');
    }
    // Implement token generation logic here
    const token = generateToken(user);
    return token;
  } catch (error) {
    throw new Error('Unable to login user');
  }
};

const updateUser = async (username, userData) => {
  try {
    const user = await User.findOneAndUpdate({ username }, userData, { new: true });
    if (!user) {
      throw new Error('User not found');
    }
    return user;
  } catch (error) {
    throw new Error('Unable to update user');
  }
};

const getCurrentUser = async (username) => {
  try {
    const user = await User.findOne({ username });
    if (!user) {
      throw new Error('User not found');
    }
    return user;
  } catch (error) {
    throw new Error('Unable to get current user');
  }
};

const logoutUser = async () => {
  try {
    // Implement logout logic here
    return 'OK';
  } catch (error) {
    throw new Error('Unable to logout user');
  }
};

module.exports = {
  registerUser,
  loginUser,
  updateUser,
  getCurrentUser,
  logoutUser,
};