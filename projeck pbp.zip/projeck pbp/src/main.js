// src/main.js

const express = require('express');
const connectDB = require('./database'); // Import konfigurasi koneksi database
const logger = require('./logging'); // Import konfigurasi logging
const errorMiddleware = require('./middleware/error-middleware'); // Import middleware error
const publicRoutes = require('./routes/public-api'); // Import rute publik

// Inisialisasi server Express
const app = express();

// Middleware
app.use(express.json());

// Rute publik
app.use('/api', publicRoutes);

// Middleware error
app.use(errorMiddleware);

// Port server
const PORT = process.env.PORT || 3000;

// Mulai server dan koneksi database
const startServer = async () => {
  try {
    await connectDB(); // Menghubungkan ke database
    app.listen(PORT, () => {
      logger.info(`Server running on port ${PORT}`);
    });
  } catch (error) {
    logger.error('Error starting server:', error);
  }
};

startServer();