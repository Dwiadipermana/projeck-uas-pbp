// routes/api.js

const express = require('express');
const userController = require('../controllers/userController');
const productController = require('../controllers/productController');

const router = express.Router();

// User routes
router.post('/users', userController.registerUser);
router.post('/users/login', userController.loginUser);
router.patch('/users/current', userController.updateUser);
// Implement other user routes (getCurrentUser, logoutUser)

// Product routes
router.post('/products', productController.createProduct);
router.put('/products/:id', productController.updateProduct);
router.get('/products/:id', productController.getProductById);
router.get('/products', productController.searchProducts);
router.delete('/products/:id', productController.deleteProduct);

module.exports = router;